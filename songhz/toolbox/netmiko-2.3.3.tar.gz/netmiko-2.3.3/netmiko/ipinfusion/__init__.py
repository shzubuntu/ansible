from __future__ import unicode_literals
from netmiko.ipinfusion.ipinfusion_ocnos import (
    IpInfusionOcNOSSSH,
    IpInfusionOcNOSTelnet,
)

__all__ = ["IpInfusionOcNOSSSH", "IpInfusionOcNOSTelnet"]
