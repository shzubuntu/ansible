from __future__ import unicode_literals
from netmiko.oneaccess.oneaccess_oneos import OneaccessOneOSSSH, OneaccessOneOSTelnet

__all__ = ["OneaccessOneOSSSH", "OneaccessOneOSTelnet"]
